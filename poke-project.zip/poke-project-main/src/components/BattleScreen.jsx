import React from 'react';
import './BattleScreen.css';

const BattleScreen = ({myPokeSelection, computerRandomSelection, enemyHealth, myHealth}) => {
    
    const validEnemyHealth = Math.max(0, Math.min(100, enemyHealth));
    const validMyHealth = Math.max(0, Math.min(100, myHealth));

    console.log({myPokeSelection});
    console.log({computerRandomSelection});
    return (
        <div className="battle-container">
            <h1>Enemy Health: {validEnemyHealth}</h1>
            <div className="health-bar">
                <div className="health-bar-inner" style={{width: `${validEnemyHealth}%`}}></div>
            </div>
            <div className="enemy-container">
                {computerRandomSelection[0] && <img src={computerRandomSelection[0].sprites.front_default} alt='enemySelection' />}
            </div>
            <h1>My Health: {validMyHealth}</h1>
            <div className="health-bar">
                <div className="health-bar-inner" style={{width: `${validMyHealth}%`}}></div>
            </div>
            <div className="my-container">
                {myPokeSelection[0] && <img src={myPokeSelection[0].sprites.front_default} alt='mySelection' />}
            </div>
        </div>
    )
}

export default BattleScreen;